//
//  ViewController.h
//  DCPathButton
//
//  Created by Paul on 3/18/13.
//  Copyright (c) 2013 Paul. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DCPathButton.h"

@interface ViewController : UIViewController
@property (strong, nonatomic) DCPathButton *dcPathButton;

@end
